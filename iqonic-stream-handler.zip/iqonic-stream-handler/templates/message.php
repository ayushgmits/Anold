<label for="custom_subscription_level" class="checkbox-label">
    <input type="checkbox" id="custom_subscription_level">
    Subscription Level
    <span class="tooltip" style="display: none;">Check this to disable the other option.</span>
</label>

<label for="custom_coins_level" class="checkbox-label">
    <input type="checkbox" id="custom_coins_level">
    Coins Level
    <span class="tooltip" style="display: none;">Check this to disable the other option.</span>
</label>
